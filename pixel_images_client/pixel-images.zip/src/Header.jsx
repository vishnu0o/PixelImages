import React from "react";

const Header = () => {
  return (
    <div class="flex items-center justify-center ">
      <div class="gold-gradient">
        <h1 class="text-4xl font-bold gold-gradient-text">A Billion Dollar Page</h1>
      </div>
    </div>
  );
};

export default Header;
